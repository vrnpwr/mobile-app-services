<?php
define("ROOT","C:/xampp/htdocs/designs/AdminLTE3/");
define("inc","C:/xampp/htdocs/designs/AdminLTE3/pages/admin/inc/");

define('base_url', 'http://localhost/designs/AdminLTE3');
 ?>